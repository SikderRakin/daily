package com.example.midproject2;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    private Spinner spinner;
    private String[]test_expanse_spinner = {"1","2","3","4","5"};
   // private ArrayAdapter<String> expanse_adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1);

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {

                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_expanse:
                    mTextMessage.setText(R.string.title_expanse);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayAdapter expanse_adapter = new ArrayAdapter(MainActivity.this,android.R.layout.simple_list_item_1);
        mTextMessage = (TextView) findViewById(R.id.message);

        spinner = findViewById(R.id.spinner);
        expanse_adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinner.setAdapter(expanse_adapter);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
