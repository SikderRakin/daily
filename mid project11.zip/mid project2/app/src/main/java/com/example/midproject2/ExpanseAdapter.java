package com.example.midproject2;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ExpanseAdapter extends RecyclerView.Adapter<ExpanseAdapter.ViewHolder> {

    Context context;
    List<Expanse_Container> expanses;

    public ExpanseAdapter(Context context, List<Expanse_Container> expanses) {
        this.context = context;
        this.expanses = expanses;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.expanse_list_layout,viewGroup, false);


        return new ViewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        Expanse_Container expanse = expanses.get(i);
        viewHolder.expenseTypeTV.setText(expanse.getExpanse_name());
        viewHolder.expenseAmountTV.setText(String.valueOf(expanse.getExpanse_amount()));
        viewHolder.expenseDateTV.setText(String.valueOf(expanse.getExpanse_date()));
        //viewHolder.expenseT.setText(String.valueOf(expanse.getExpanse_time()));

    }

    @Override
    public int getItemCount() {
        return expanses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        private TextView expenseTypeTV,expenseDateTV,expenseAmountTV;
        private ImageView expanseImageIV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            expenseTypeTV = itemView.findViewById(R.id.expenseTypeTV);
            expenseDateTV = itemView.findViewById(R.id.expenseDateTV);
            expenseAmountTV = itemView.findViewById(R.id.expenseAmountTV);
            expanseImageIV = itemView.findViewById(R.id.expanseImageIV);


        }
    }
}
