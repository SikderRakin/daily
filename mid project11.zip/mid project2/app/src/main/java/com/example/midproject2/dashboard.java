package com.example.midproject2;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;


/**
 * A simple {@link Fragment} subclass.
 */
public class dashboard extends Fragment {

    private Spinner spinner;
    private String[]test_expanse_spinner = {"1","2","3","4","5"};
    public dashboard() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Dashboard");
        View view = inflater.inflate(R.layout.fragment_dashboard,container,false);
        //ArrayAdapter<String> expanse_adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.test_expanse_spinner));

        ArrayAdapter<String> expanse_adapter = new ArrayAdapter<String>(this.getActivity(),android.R.layout.simple_list_item_1,test_expanse_spinner);
        spinner = view.findViewById(R.id.spinner);
        //expanse_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        expanse_adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinner.setAdapter(expanse_adapter);

        // Inflate the layout for this fragment

        //return inflater.inflate(R.layout.fragment_dashboard, container, false);
        return  view;
    }

}
