package com.example.midproject2;


import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class expanse extends Fragment {

    private FloatingActionButton floatingActionButton;
    private RecyclerView recyclerView;
    private ExpanseAdapter expanseAdapter;
    private List<Expanse_Container> expanse_list = new ArrayList<>();
    private DatabaseHelper helper;
    private Button button_test;
    private  View view_global;

    public expanse() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_expanse, container, false);
        view_global= view;
        getActivity().setTitle("Expanse");


        show_data();







        floatingActionButton=view.findViewById(R.id.addExpanseFAB);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainAct= (MainActivity) getActivity();
                mainAct.addExpanseFragment();

            }
        });
        return view;

    }



    public void show_data(){

        recyclerView = view_global.findViewById(R.id.expanseRecycler);

        helper = new DatabaseHelper(getActivity());
        Cursor cursor =  helper.showData();


        while(cursor.moveToNext()){

            int id = cursor.getInt(cursor.getColumnIndex(helper.COL_ID));
            String expanse_name =cursor.getString(cursor.getColumnIndex(helper.COL_EXPANSE_NAME));
            int expanse_amount =cursor.getInt(cursor.getColumnIndex(helper.COL_EXPANSE_AMOUNT));



            // add date and time here //


            Toast.makeText(getActivity(), ""+expanse_amount, Toast.LENGTH_SHORT).show();
            expanse_list.add(new Expanse_Container(id,expanse_name,expanse_amount,1, 1));
        }
        expanseAdapter = new ExpanseAdapter(this.getActivity(),expanse_list);        //can have error//

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        recyclerView.setAdapter(expanseAdapter);

    }




}
